# Séance 5 - Panel dynamique et GMM
# Script étudiant R - à compléter (équivalent de la fiche TD_etudiant_seance_5.pdf)
library(here)
library(haven)
library(dplyr)
library(fixest)
library(plm)        # pgmm : équivalent d'xtabond2

ls <- read_dta(here("04_Donnees", "labor_supply.dta")) |> zap_labels() |> zap_formats() |>
  arrange(id, year) |> group_by(id) |> mutate(l_lnhr = dplyr::lag(lnhr)) |> ungroup()

# Exercice 1 - Encadrer la persistance : MCO groupés puis effets fixes avec l_lnhr
# Exercice 2 - Conditions de moments : sur papier
# Exercice 3 - GMM en différences et système
# pls <- pdata.frame(as.data.frame(ls), index = c("id", "year"))
# diff <- pgmm(lnhr ~ lag(lnhr, 1) + lnwg + age + agesq + kids + disab |
#                lag(lnhr, 2:3) + lag(lnwg, 2:3) + lag(kids, 2:3) + lag(disab, 2:3) | age + agesq,
#              data = pls, effect = "twoways", model = "twosteps", transformation = "d",
#              collapse = TRUE)
# système : transformation = "ld"
# Exercice 4 - Audit : summary(m, robust = TRUE), mtest(m, order = 2), sargan(m),
#              nombre d'instruments ncol(m$W[[1]])
