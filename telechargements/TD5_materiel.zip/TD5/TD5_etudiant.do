* Séance 5 - Panel dynamique et GMM
* Do-file étudiant - à compléter
* Répertoire courant attendu : dossier racine de la séance 5 (contient 04_Donnees/)
version 17
clear all
set more off
capture log close
capture confirm file "04_Donnees/labor_supply.dta"
if _rc {
    di as error "Dans Stata, définissez comme répertoire courant le dossier racine de la séance 5."
    exit 601
}
capture which xtabond2
if _rc {
    di as error "Installez xtabond2 avant la séance avec ssc install xtabond2."
    exit 199
}
capture mkdir "03_Sorties"
log using "03_Sorties/TD5_etudiant.log", text replace
use "04_Donnees/labor_supply.dta", clear
xtset id year
tab year, generate(yr)
* Avec L.lnhr, l'échantillon commence en 1980 : utiliser yr3-yr10 (référence 1980)

*==============================================================
* Exercice 1 - Encadrer la persistance
*==============================================================
* reg lnhr L.lnhr ... yr3-yr10, vce(cluster id) ; xtreg ..., fe vce(cluster id)

*==============================================================
* Exercice 2 - Conditions de moments : sur papier
*==============================================================

*==============================================================
* Exercice 3 - GMM en différences et GMM système
*==============================================================
* xtabond2 lnhr L.lnhr lnwg age agesq kids disab yr3-yr10, ///
*     gmmstyle(L.lnhr, laglimits(1 2) collapse) gmmstyle(lnwg kids disab, laglimits(2 3) collapse) ///
*     ivstyle(age agesq yr3-yr10) twostep robust small noleveleq

*==============================================================
* Exercice 4 - Audit du modèle
*==============================================================
* estimates table ..., stats(N N_g j ar1p ar2p hansenp)

log close
