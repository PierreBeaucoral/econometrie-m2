* Séance de révision - exercices sur machine (à faire en binôme)
* Répertoire courant attendu : dossier S0_revision (contient 04_Donnees/)
version 17
clear all
set more off
capture log close
capture confirm file "04_Donnees/card.dta"
if _rc {
    di as error "Dans Stata, définissez comme répertoire courant le dossier S0_revision."
    exit 601
}
capture mkdir "03_Sorties"
log using "03_Sorties/S0_etudiant.log", text replace

*==============================================================
* À vous 1 - Frisch-Waugh-Lovell (Card 1995)
*==============================================================
use "04_Donnees/card.dta", clear
* 1. reg lwage educ exper expersq black south smsa, vce(robust) : noter b_educ
* 2. régresser educ sur les cinq contrôles et garder le résidu (predict ..., residuals)
* 3. régresser lwage sur les cinq contrôles et garder le résidu
* 4. régresser le résidu de lwage sur le résidu de educ, sans constante. Comparer à 1.

*==============================================================
* À vous 2 - Biais de variable omise : la contribution de l'expérience
*==============================================================
* 1. gamma = coefficient de exper dans le modèle complet
* 2. delta = coefficient de educ dans : reg exper educ
* 3. calculer gamma * delta (display) : signe ? ordre de grandeur ?

*==============================================================
* À vous 3 - L'estimateur VI comme rapport (AJR 2001)
*==============================================================
use "04_Donnees/colonial_origins.dta", clear
keep if baseco == 1
* 1. première étape : reg avexpr logem4 lat_abst, vce(robust) ; garder _b[logem4]
* 2. forme réduite  : reg logpgp95 logem4 lat_abst, vce(robust) ; garder _b[logem4]
* 3. calculer le rapport, puis comparer à : ivregress 2sls logpgp95 lat_abst (avexpr = logem4), vce(robust)

*==============================================================
* À vous 4 - Diagnostiquer l'instrument
*==============================================================
* 1. après ivregress : estat firststage (F robuste)
* 2. estat weakrobust (Stata 18 ou plus) ou ivreg2 ..., robust ffirst (Anderson-Rubin)
* 3. conclure : l'instrument est-il faible ? le test AR rejette-t-il beta = 0 ?

log close
