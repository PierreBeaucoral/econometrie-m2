# Séance de révision - exercices sur machine (à faire en binôme), version R
# Ouvrir R dans le dossier S0_revision (qui contient .here et 04_Donnees/)
library(here)
library(haven)
library(fixest)

card <- read_dta(here("04_Donnees", "card.dta"))
ajr  <- read_dta(here("04_Donnees", "colonial_origins.dta"))
ajr  <- ajr[ajr$baseco == 1, ]

# À vous 1 - Frisch-Waugh-Lovell
# m  <- feols(lwage ~ educ + exper + expersq + black + south + smsa, card, vcov = "hetero")
# r_educ  <- resid(feols(educ  ~ exper + expersq + black + south + smsa, card))
# r_lwage <- resid(feols(lwage ~ exper + expersq + black + south + smsa, card))
# feols(r_lwage ~ -1 + r_educ, data.frame(r_lwage, r_educ), vcov = "hetero")

# À vous 2 - Biais de variable omise : gamma (exper, modèle complet) x delta (educ dans exper ~ educ)

# À vous 3 - L'estimateur VI comme rapport
# fs <- feols(avexpr ~ logem4 + lat_abst, ajr, vcov = "hetero")
# rf <- feols(logpgp95 ~ logem4 + lat_abst, ajr, vcov = "hetero")
# coef(rf)["logem4"] / coef(fs)["logem4"]
# iv <- feols(logpgp95 ~ lat_abst | avexpr ~ logem4, ajr, vcov = "hetero")

# À vous 4 - Diagnostiquer l'instrument
# fitstat(iv, ~ ivwald)          # F robuste de première étape
# wald(rf, keep = "logem4")      # Anderson-Rubin (H0 : beta = 0) = test de la forme réduite
