* Séance 7 - Instrument shift-share (à un seul choc) en panel : aide alimentaire et conflits
* Do-file étudiant - à compléter
* Répertoire courant attendu : dossier racine de la séance 7 (contient 04_Donnees/)
version 17
clear all
set more off
set seed 20261124                    // unique graine du do-file (exercice 4)
capture log close
capture confirm file "04_Donnees/nunn_qian_td7.dta"
if _rc {
    di as error "Dans Stata, définissez comme répertoire courant le dossier racine de la séance 7."
    exit 601
}
foreach cmd in ivreg2 ranktest ivreghdfe reghdfe ftools require {
    capture which `cmd'
    if _rc {
        di as error "Installez `cmd' avant la séance : ssc install `cmd'"
        exit 199
    }
}
capture mkdir "03_Sorties"
log using "03_Sorties/TD7_etudiant.log", text replace
use "04_Donnees/nunn_qian_td7.dta", clear
encode risocode, gen(cid)
encode wb_region, gen(region)

*==============================================================
* Exercice 1 - Décrire le panel et construire l'instrument
*==============================================================
* Q1 : xtset cid year ; xtdescribe
* Q2 : vérifier instrument = l_US_wheat_production * fadum_avg (assert)
* Q3 : (réponse écrite)
* Q4 : collapse par année et par groupe (fadum_avg au-dessus / au-dessous de la médiane)

*==============================================================
* Exercice 2 - Répliquer le tableau 2, colonnes 1 et 2
*==============================================================
* Q1 : xi: ivreg2 any_war (wheat_aid=instrument) i.risocode i.year*i.wb_region, cluster(risocode) ffirst
*      puis reghdfe (MCO, première étape, forme réduite) et ivreghdfe,
*      absorb(cid i.year#i.region) cluster(cid)
* Q2-Q4 : comparer, interpréter

*==============================================================
* Exercice 3 - Tendances différentielles
*==============================================================
* Q2 : gen fad_t = fadum_avg * (year - 1971) ; l'ajouter comme contrôle
* Q3 : ajouter fad_t2 = fadum_avg * (year - 1971)^2

*==============================================================
* Exercice 4 - Placebo (commencer avec R = 50 tirages)
*==============================================================
local R 5    // passer à 50 une fois la boucle complétée
tempfile base
save `base'
tempname sims
postfile `sims' int tirage str5 serie double(t_fs t_rf t_iv) using "03_Sorties/TD7_placebo_etudiant.dta", replace
forvalues r = 1/`R' {
    clear
    quietly set obs 71
    gen int year = 1935 + _n
    gen double e  = runiform() - 0.5
    gen double rw = 100 + sum(e)          // marche aléatoire
    gen double wn = 100 + e               // bruit blanc
    tsset year
    gen double l_rw = L.rw
    gen double l_wn = L.wn
    keep year l_rw l_wn
    tempfile serie
    quietly save `serie'
    use `base', clear
    quietly merge m:1 year using `serie', keep(match) nogenerate
    foreach s in rw wn {
        gen double faux = l_`s' * fadum_avg
        * À compléter : première étape, forme réduite et 2SLS avec faux comme instrument,
        * en stockant les statistiques t dans les scalaires tfs, trf et tiv
        scalar tfs = .
        scalar trf = .
        scalar tiv = .
        post `sims' (`r') ("`s'") (tfs) (trf) (tiv)
        drop faux
    }
}
postclose `sims'
* Q2 : charger le fichier de résultats et calculer la part des |t| > 1,96
* Q3 : recommencer avec cluster(year)
* Q4 : colonne 1 avec cluster(year)

log close
