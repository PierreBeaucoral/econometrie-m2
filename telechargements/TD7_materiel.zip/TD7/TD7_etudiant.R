# Séance 7 - Instrument shift-share (à un seul choc) en panel : aide alimentaire et conflits
# Script étudiant R - à compléter (équivalent de TD7_etudiant.do)
library(here)
library(haven)
library(dplyr)
library(fixest)
library(ggplot2)

set.seed(20261124)   # unique graine du script (exercice 4)

nq <- read_dta(here("04_Donnees", "nunn_qian_td7.dta")) |> zap_labels() |> zap_formats()
fe <- "risocode + wb_region^year"

# Exercice 1 - Décrire le panel et construire l'instrument
# Q2 : vérifier instrument == l_US_wheat_production * fadum_avg (écart relatif < 1e-6)
# Q4 : moyennes annuelles de any_war pour fadum_avg au-dessus / au-dessous de la médiane

# Exercice 2 - Tableau 2, colonnes 1 et 2
# iv <- feols(as.formula(paste("any_war ~ 1 |", fe, "| wheat_aid ~ instrument")), nq,
#             cluster = ~risocode)

# Exercice 3 - Tendances différentielles : ajouter fadum_avg * (year - 1971), puis son carré

# Exercice 4 - Placebo (commencer avec 5 tirages, puis 50)
n_tirages <- 5L
annees <- 1936:2006
resultats <- vector("list", n_tirages * 2L)
k <- 0L
for (r in seq_len(n_tirages)) {
  e <- runif(length(annees)) - 0.5
  serie <- tibble(year = annees, rw = 100 + cumsum(e), wn = 100 + e) |>
    mutate(l_rw = lag(rw), l_wn = lag(wn))
  d <- left_join(nq, serie, by = "year")
  for (s in c("rw", "wn")) {
    d$faux <- d[[paste0("l_", s)]] * d$fadum_avg
    k <- k + 1L
    # À compléter : première étape, forme réduite et 2SLS avec faux comme instrument ;
    # récupérer les statistiques t avec tstat()
    resultats[[k]] <- data.frame(tirage = r, serie = s, t_fs = NA, t_rf = NA, t_iv = NA)
  }
}
placebo <- bind_rows(resultats)
# Q2 : part des |t| > 1.96 par série ; Q3 : recommencer avec cluster = ~year
