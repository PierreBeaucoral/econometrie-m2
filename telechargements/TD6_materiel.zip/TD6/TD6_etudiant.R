# Séance 6 - Variables instrumentales en panel : pluie, croissance et conflits
# Script étudiant R - à compléter (équivalent de TD6_etudiant.do)
library(here)
library(haven)
library(dplyr)
library(fixest)
library(ggplot2)

mss <- read_dta(here("04_Donnees", "mss_repdata.dta")) |> zap_labels() |>
  mutate(trend = year - 1978)

# Exercice 1 - Décrire le panel et l'instrument
# Q1 : pays, années, équilibre ; Q2 : global / between / within
# Q3 : cor(mss$GPCP_g, mss$GPCP_g_l)
# Q4 : résidus de feols(gdp_g ~ 1 | ccode[trend]) et feols(GPCP_g ~ 1 | ccode[trend]), nuage

# Exercice 2 - Première étape et forme réduite
# fs <- feols(gdp_g ~ GPCP_g + GPCP_g_l | ccode[trend], mss, cluster = ~ccode)
# wald(fs, keep = "GPCP")
# rf <- feols(any_prio ~ GPCP_g + GPCP_g_l | ccode[trend], mss, cluster = ~ccode)

# Exercice 3 - MCO contre 2SLS
# iv <- feols(any_prio ~ 1 | ccode[trend] | gdp_g + gdp_g_l ~ GPCP_g + GPCP_g_l,
#             mss, cluster = ~ccode)
# Q2 : summary(iv, ssc = ssc(fixef.K = "full")) reproduit ivregress, small
# Q3 : fitstat(iv, ~ ivwald) ; Anderson-Rubin (beta = 0) : wald(rf, keep = "GPCP")

# Exercice 4 - Exclusion et mesure de l'instrument
# GPCP_{t-1} = GPCP / (1 + GPCP_g) ; instrumenter par log(GPCP) et log(GPCP_{t-1})
