* Séance 6 - Variables instrumentales en panel : pluie, croissance et conflits
* Do-file étudiant - à compléter
* Répertoire courant attendu : dossier racine de la séance 6 (contient 04_Donnees/)
version 17
clear all
set more off
capture log close
capture confirm file "04_Donnees/mss_repdata.dta"
if _rc {
    di as error "Dans Stata, définissez comme répertoire courant le dossier racine de la séance 6."
    exit 601
}
foreach cmd in ivreg2 ranktest ivreghdfe reghdfe ftools require {
    capture which `cmd'
    if _rc {
        di as error "Installez `cmd' avant la séance : ssc install `cmd'"
        exit 199
    }
}
capture mkdir "03_Sorties"
log using "03_Sorties/TD6_etudiant.log", text replace
use "04_Donnees/mss_repdata.dta", clear
gen trend = year - 1978

*==============================================================
* Exercice 1 - Décrire le panel et l'instrument
*==============================================================
* Q1 : déclarer le panel et décrire sa structure
* Q2 : variation within / between de any_prio, gdp_g, GPCP_g
* Q3 : corrélation entre GPCP_g et GPCP_g_l
* Q4 : résidualiser gdp_g et GPCP_g sur ccode et ccode#c.trend (reghdfe, resid())
*      puis tracer le nuage et la droite d'ajustement

*==============================================================
* Exercice 2 - Première étape et forme réduite
*==============================================================
* Q1 : regress gdp_g sur GPCP_g GPCP_g_l, i.ccode i.ccode#c.trend, vce(cluster ccode)
* Q2 : test conjoint des deux instruments
* Q3 : forme réduite de any_prio sur les mêmes variables
* Q4 : (réponse écrite)

*==============================================================
* Exercice 3 - MCO contre 2SLS en panel
*==============================================================
* Q1 : MCO puis ivregress 2sls ... , vce(cluster ccode) small, pour any_prio et war_prio
* Q2 : même modèle avec ivreghdfe ..., absorb(ccode ccode#c.trend) cluster(ccode) ffirst
* Q3-Q4 : lire Kleibergen-Paap, Stock-Yogo, Anderson-Rubin dans la sortie

*==============================================================
* Exercice 4 - Exclusion et mesure de l'instrument
*==============================================================
* Q2 : GPCP_{t-1} = GPCP / (1 + GPCP_g) ; vérifier avec L.GPCP ; puis
*      ivreghdfe any_prio (gdp_g gdp_g_l = ln_rain ln_rain_l), absorb(...) cluster(ccode) ffirst

log close
