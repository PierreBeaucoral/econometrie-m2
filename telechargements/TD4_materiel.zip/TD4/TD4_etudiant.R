# Séance 4 - Données de panel et effets fixes
# Script étudiant R - à compléter (équivalent de la fiche TD_etudiant_seance_4.pdf)
# Lancer depuis le dossier de la séance (qui contient .here et 04_Donnees/)
library(here)
library(haven)
library(dplyr)
library(fixest)
library(plm)        # effets aléatoires, Hausman ; attention : masque dplyr::lag
library(lmtest)
library(ggplot2)

ls <- read_dta(here("04_Donnees", "labor_supply.dta")) |> zap_labels() |> zap_formats()

# Exercice 1 - Décrire la variation du panel
# Q1 : nombre d'individus, d'années, équilibre du panel
# Q2 : écarts types global / between / within (équivalent de xtsum)
# Q3 : variables faiblement identifiées par les effets fixes (regarder age - dplyr::lag(age))
# Q4 : lnhr et lnwg pour quatre individus (ggplot2 + facet_wrap)

# Exercice 2 - MCO groupés et effets fixes
# pooled <- feols(lnhr ~ lnwg + age + agesq + kids + disab | year, ls, cluster = ~id)
# fe     <- feols(lnhr ~ lnwg + age + agesq + kids + disab | id + year, ls, cluster = ~id)

# Exercice 3 - Transformation within
# Centrer chaque variable sur sa moyenne individuelle (group_by(id) |> mutate(...)),
# estimer sans constante et comparer à feols(... | id)

# Exercice 4 - Effets aléatoires et choix du modèle
# pls <- pdata.frame(ls, index = c("id", "year"))
# re  <- plm(lnhr ~ lnwg + age + agesq + kids + disab + factor(year), pls, model = "random")
# phtest(fe_plm, re) ; test de Mundlak : ajouter les moyennes individuelles des régresseurs
