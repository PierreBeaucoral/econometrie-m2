* Séance 4 - Données de panel et effets fixes
* Do-file étudiant - à compléter
* Répertoire courant attendu : dossier racine de la séance 4 (contient 04_Donnees/)
version 17
clear all
set more off
capture log close
capture confirm file "04_Donnees/labor_supply.dta"
if _rc {
    di as error "Dans Stata, définissez comme répertoire courant le dossier racine de la séance 4."
    exit 601
}
capture mkdir "03_Sorties"
log using "03_Sorties/TD4_etudiant.log", text replace
use "04_Donnees/labor_supply.dta", clear

*==============================================================
* Exercice 1 - Décrire la variation du panel
*==============================================================
* Q1 : xtset id year ; xtdescribe
* Q2 : xtsum lnhr lnwg age agesq kids disab
* Q3 : variables faiblement identifiées (examiner l'évolution de age d'une année à l'autre)
* Q4 : lnhr et lnwg pour quatre individus choisis de manière reproductible

*==============================================================
* Exercice 2 - MCO groupés et effets fixes
*==============================================================
* reg ... i.year, vce(cluster id) ; xtreg ... i.year, fe vce(cluster id)

*==============================================================
* Exercice 3 - Transformation within
*==============================================================
* bysort id: egen ... = mean() ; variables centrées ; reg ..., nocons vce(cluster id)

*==============================================================
* Exercice 4 - Effets aléatoires et choix du modèle
*==============================================================
* xtreg ..., re ; estimates store ; hausman ..., sigmamore
* test de Mundlak : ajouter les moyennes individuelles, vce(cluster id), test joint

log close
